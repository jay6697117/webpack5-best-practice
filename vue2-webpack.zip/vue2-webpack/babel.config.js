module.exports = {
  plugins: [
    // element-ui 按需加载
    [
      "component", // babel-plugin-component
      {
        libraryName: "element-ui",
        styleLibraryName: "theme-chalk",
      },
    ],
  ],
};
