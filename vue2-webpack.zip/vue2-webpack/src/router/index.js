import Vue from "vue";
import VueRouter from "vue-router";
import Foo from "../pages/Foo.vue";

Vue.use(VueRouter);

const Bar = () => import(/* webpackChunkName: "group-bar" */ "../pages/Bar.vue"); // 异步加载文件:路由懒加载
const routes = [
  { path: "/foo", name: "Foo", component: Foo },
  { path: "/bar", name: "Bar", component: Bar }
];
const router = new VueRouter({
  routes
});

export default router;
