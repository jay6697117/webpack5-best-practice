<template>
  <div>foo</div>
</template>
