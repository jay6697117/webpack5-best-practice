<template>
  <div>bar</div>
</template>
