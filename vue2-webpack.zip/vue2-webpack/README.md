# 徒手搞定Vue + Webpack配置，不用Vue-CLI

## 安装

```
npm install
```

## 运行

webpack dev server
```
npm start
```
webpack 打包，监听文件变化

```
npm run watch
```

webpack 打包

```
npm run build
```
